import algorithms.tree.Huffman;

public class Main5 {
    // * I can not get the codes to be correct ???
    public static void main(String[] args) {
        Huffman huffman = new Huffman();
        String filePath = "./data/huffman.in";

        huffman.run(huffman, filePath);
    }
}
