# Assignment 0

## Instructions

Run the following commands in the terminal one line at the time to run each problems solution.

```bash
    go run p1.go # To run problem 1
    go run p2.go # To run problem 2
    go run p3.go # To run problem 3
    go run p4.go # To run problem 4
```
