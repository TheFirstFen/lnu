# 1dt909

## Emil Ulvagården (eu222dq)

### Introduction

#### Köra programen

```PowerShell
go run dice.go

go run randWalk.go

go run bst.go

go run quickSort.go

```
