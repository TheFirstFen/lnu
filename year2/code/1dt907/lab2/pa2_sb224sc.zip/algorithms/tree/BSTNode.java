package algorithms.tree;

public class BSTNode {
    int key;
    BSTNode l, r;

    public BSTNode(int item) {
        key = item;
        l = r = null;
    }
}
