# Additions
To add a book, you have the option to input a negative quantity, ensuring that the total quantity for that book in the cart does not fall below zero, given that the book is already present. If the calculated quantity does not surpass zero, it will subtract the specified number of books from the selected title. Only when the quantity reaches zero will the book be removed from the cart.

Also added that the user has a empty cart you follow through with the checkout.