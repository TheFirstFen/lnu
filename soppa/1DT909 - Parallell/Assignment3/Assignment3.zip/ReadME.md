# ASSIGNMENT 2

The first problem is run by moving into folders Assignment3/problem1 then running 'go run srv.go' after that open a new terminal
and run 'go run problem1.go'

The second problem cant be run without the database but the server is located in newsrv folder and the client is in program2.go.