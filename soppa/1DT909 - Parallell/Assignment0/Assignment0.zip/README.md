Assignment 0

To run the problems go into the Assignment0 folder then use the command
'go run problemx/problemx.go' where the 'x' should be replaced with the number of the problem.

