# Instructions for assignment 1

Question 1,2,5,6 could be run by theirselves, they contain small tests.

The programs problem4 and problem7 calculate the time to compute the given algorithms and prints them as a list.
These lists have then been manually placed in the python display programs which displays them in scatterplots.