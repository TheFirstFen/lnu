# Problem 1
Problem 1 is tested through GraphExample.java

# Problem 2
Problem 2 is run through GraphTraversalTest.java

# Problem 3
Problem 3 is run through KruskalTest.java

# Problem 4
Problem 4 is tested in ShortestPath.java

# Problem 5
Problem 5 is solved in CourseOrder.java