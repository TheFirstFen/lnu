# Assignment 2 algorithms

## Problem 1
To check problem 1 just run the program called Queue.java and the 
result shows some of the test cases that showcases the result. There is comments in the code displaying what should happen at each output.

## Problem 2
Problem 2 is ran through the problem2.java file and the output explains itself.
Uses the files AVLNode.java, AVLTree.java, btNode.java and BST.java.

## Problem 3
Problem 3 is ran through the problem3.java file and in the problem3scaling.py the graphs are produced.
Uses the files PQAsHeap.java and HeapNode.java.

## Problem 4
Problem 4 is solved in problem4.java so run that and the output explains the results found. This uses QuickSort.java 
InsertSort.java and HeapSort.java