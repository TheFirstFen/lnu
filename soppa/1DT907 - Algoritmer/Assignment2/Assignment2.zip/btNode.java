package Assignment2;

public class btNode {
    public int key;
    public btNode left;
    public btNode right;

    public btNode(Integer k) {
        key = k;
    }
}
