% Task 5
a = linspace(0, 4*pi, 1000);

x = 2 * cos(a);
y = 2 * sin(a);
z = a;


plot3(x, y, z);

axis equal;
