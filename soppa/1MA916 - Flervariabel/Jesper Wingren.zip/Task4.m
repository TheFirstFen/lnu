% Task 4
a = linspace(0, 2*pi, 1000);

x = sin(2*a);
y = cos(2*a);
z = sin(3*a);

plot3(x, y, z);

axis equal;
