% Task 10
f = @(x) 1 ./ (1 + x).^2;

result = integral(f, 0, 1)
