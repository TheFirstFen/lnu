% Task 3
a = linspace(0, 2*pi, 1000);

r = 1 - sin(4*a);

polarplot(a, r);
