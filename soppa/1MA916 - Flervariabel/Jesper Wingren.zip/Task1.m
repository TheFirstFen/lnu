% Task1
clear
t = 0 : 0.01 : 5;
x = 4 + t.^3;
y = 1 + 5 * t.^2;
plot(x, y)