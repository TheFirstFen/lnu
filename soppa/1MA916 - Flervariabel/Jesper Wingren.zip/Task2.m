% Task 2
a = linspace(0, 2*pi, 100);

x = 3 * cos(a);
y = 3 * sin(a);

plot(x,y)
axis equal;