// Only include standard c++ library's
#ifndef MYLIBS_H
#define MYLIBS_H

#include <iostream>
#include <ctime>
#include <vector>
#include <string>

#endif