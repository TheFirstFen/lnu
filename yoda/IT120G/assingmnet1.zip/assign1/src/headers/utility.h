#ifndef UTILITY_H
#define UTILITY_H

#include <iostream>
#include <ctime>

char betType();
int wheelSpin();
int betAmount(int accountAmount);
int gameTable(char choice, int bet);
bool isBetCorrectValue(int bet);


#endif
